﻿/// <reference path="" />
var logItem = null;
function debug_Sms(logItemObject) {
    logItem = logItemObject;
   
}
function debug_sendSms(mobile, text) {
    debug_SmsAddLog("----------------------------------");
    debug_SmsAddLog("sending sms.. ");
    debug_SmsAddLog("number:" + mobile);
    $.get("../SMScallBackPage.aspx", { mobileNumber: mobile, smsText: text }, function (data, status) {
        debug_SmsAddLog("Response:" + (data=="ok" || data=="fail"?data:"other data..") + "\t status:" + status);
    });
}
function debug_SmsAddLog(logText) {
    
    $(logItem).val("["+new Date().toTimeString()+"]\t"+logText + "\n" + $(logItem).val())
}