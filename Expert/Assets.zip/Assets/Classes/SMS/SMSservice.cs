﻿using ir.expert.DB;
using ir.expert.user;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ir.expert.SMS
{
    public static class SMSservice
    {
        public static Boolean gotSMSfromUser (string paraUserName,string paraSMS)
        {
            if (DbUtilities.isUserStatusEnable(paraUserName, user.user.UserStatus.USER_STATUS_VERIFING)){
                if (isUserSMSandVerifyKeyOK(paraUserName, paraSMS,paraUserName))
                {
                    DbUtilities.disableUserStatus(paraUserName, user.user.UserStatus.USER_STATUS_VERIFING);
                    
                }
            }
            throw new NotImplementedException();
        }
        private static Boolean isUserSMSandVerifyKeyOK(string paraUserSMS,string paraSMS,string paraUserName)
        {
            user.user userToCheck = Users.getOnlineUser(paraUserName);
            if (userToCheck != null)
            {
                if (userToCheck.LastVerificationCode == paraSMS)
                {
                    return true;
                }
            }
            return false;

           // throw new NotImplementedException();
        }
    }
}