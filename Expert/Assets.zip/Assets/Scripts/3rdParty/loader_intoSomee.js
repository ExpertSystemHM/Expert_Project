﻿$(document).ready(function () {
    $(document.body).html("");
});