﻿var hub=null;
function register_user(name,family,password,mobile,username){
    hub.server.registerUser(name, family, password, mobile, username).done(function (result) {
        if (result) {
            alert("you have been registered!");
            $.mobile.changePage("#pagev", { transition: "slideup" });
            getVerificationCode();
            var scope = $("#verification_win").scope();
            scope.$apply(function () {
                scope.start_timer();
            });
           
        } else {
            alert("already done with this user name!");
        }
    });

}
function getVerificationCode() {
    hub.server.getVerificationCode().done(function (result) {
        var scope = $("#verification_win").scope();
        scope.$apply(function () {
            scope.verificationCode=result;
        });
    });
    
}
function check_username_availablity( username) {
    hub.server.checkUserNameAvailablity(username).done(function (result) {
        if (result) {
            alert("yes,you can");
        } else {
            alert("no,sorry!");
        }
    });

}
$(function () {
    hub = $.connection.sysetemHub;
   
    
   
    hub.client.showAppFace = function (type, message) {
        
        switch (type) {

            case 1:
         
                break;
            case 2:
              

                $(':mobile-pagecontainer').pagecontainer('change', '#pageVerify');
                break;
        };
    };
   
    $.connection.hub.start().done(function () {
        $('#btn_login').click(function () {
            hub.server.send("!", "1");

        });
    });
});